const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const bcrypt = require('bcrypt');
const User = require('./user');
const Admin = require('./admin');

passport.use('user', new LocalStrategy(async (username, password, done) => {
    try {
        const user = await User.findOne({ username });
        if (!user) {
            return done(null, false, { message: 'Usuario y/o contraseña incorrecta' });
        }
        const isCorrectPassword = await user.isCorrectPassword(password);
        if (isCorrectPassword) {
            return done(null, user);
        } else {
            return done(null, false, { message: 'Usuario y/o contraseña incorrecta' });
        }
    } catch (error) {
        return done(error);
    }
}));

passport.use('admin', new LocalStrategy(async (username, password, done) => {
    try {
        const admin = await Admin.findOne({ username });
        if (!admin) {
            return done(null, false, { message: 'Usuario y/o contraseña incorrecta' });
        }
        const isCorrectPassword = await bcrypt.compare(password, admin.password);
        if (isCorrectPassword) {
            return done(null, admin);
        } else {
            return done(null, false, { message: 'Usuario y/o contraseña incorrecta' });
        }
    } catch (error) {
        return done(error);
    }
}));

passport.serializeUser((user, done) => {
    done(null, user.id);
});

passport.deserializeUser(async (id, done) => {
    try {
        const user = await User.findById(id);
        if (user) {
            return done(null, user);
        }
        const admin = await Admin.findById(id);
        return done(null, admin);
    } catch (error) {
        return done(error);
    }
});

module.exports = passport;
