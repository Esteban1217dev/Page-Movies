const express = require('express');
const path = require('path');
const bcrypt = require('bcrypt');
const mongoose = require('mongoose');
const session = require('express-session');
const passport = require('./Passport'); 
const User = require('./user');
const Admin = require('./admin');
const Peliculas = require('./peliculas');

const app = express();

const mongo_uri = 'mongodb://localhost:27017/usuarios';

mongoose.connect(mongo_uri, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log(`Successfully connected to ${mongo_uri}`);
        app.listen(3000, () => {
            console.log('Server started on port 3000');
        });
    })
    .catch(err => {
        console.error('Error connecting to MongoDB:', err);
    });

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'inicio.html'));
});

app.get('/administrador', (req, res) => {
    if (req.isAuthenticated() && req.user instanceof Admin) {
        res.sendFile(path.join(__dirname, 'public', 'indexadm.html'));
    } else {
        res.redirect('/login'); // Redirige a la página de inicio de sesión si el usuario no es administrador o no está autenticado
    }
});

app.get('/signupadm', (req, res) => {
    if (req.isAuthenticated() && req.user instanceof Admin) {
        res.sendFile(path.join(__dirname, 'public', 'signupadm.html'));
    } else {
        res.redirect('/login'); // Redirige a la página de inicio de sesión si el usuario no es administrador o no está autenticado
    }
});

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Configuración de la sesión
app.use(session({
    secret: 'mysecretkey',
    resave: true,
    saveUninitialized: true
}));

// Inicialización de Passport
app.use(passport.initialize());
app.use(passport.session());

// Middleware para mantener la sesión del usuario o administrador incluso después de recargar la página
passport.serializeUser((user, done) => {
    done(null, user);
});

passport.deserializeUser((obj, done) => {
    done(null, obj);
});

// Ruta para comprobar si el usuario es administrador
app.get('/checkadmin', (req, res) => {
    if (req.isAuthenticated() && req.user instanceof Admin) {
        res.json({ esAdmin: true }); // Si es administrador
    } else {
        res.json({ esAdmin: false }); // Si no es administrador
    }
});

// Rutas de autenticación de usuario
app.post('/authenticate', passport.authenticate('user', {
    successRedirect: '/princi.html',
    failureRedirect: '/',
    failureFlash: true
}));

// Rutas de autenticación de administrador
app.post('/authenticateadmin', passport.authenticate('admin', {
    successRedirect: '/princi.html',
    failureRedirect: '/administrador',
    failureFlash: true
}));

// Middleware para verificar si el usuario es administrador
const isAdmin = (req, res, next) => {
    if (req.isAuthenticated() && req.user instanceof Admin) {
        next(); // Si es administrador, continúa con la siguiente función
    } else {
        res.status(403).send('Acceso denegado. Debes ser administrador para acceder a esta función');
    }
};

// Ruta para guardar película
app.post('/guardarpelicula', async (req, res) => {
    const { titulo, anio, director, actores, imagen } = req.body;
    const usuarioId = req.user._id; // Recuperamos el ID del usuario o administrador autenticado

    console.log('Datos recibidos para guardar la película:', { titulo, anio, director, actores, imagen });

    try {
        const pelicula = new Peliculas({ titulo, anio, director, actores, imagen, usuario: usuarioId });
        await pelicula.save();
        console.log('Película guardada en la base de datos:', pelicula);
        res.redirect('/princi.html');
    } catch (error) {
        console.error('Error al guardar la película:', error);
        res.status(500).send('ERROR AL GUARDAR LA PELÍCULA');
    }
});

// Ruta para obtener todas las películas
app.get('/api/peliculas', async (req, res) => {
    try {
        const peliculas = await Peliculas.find().populate('usuario');
        res.json(peliculas);
    } catch (error) {
        console.error('Error al obtener películas:', error);
        res.status(500).send('ERROR AL OBTENER LAS PELÍCULAS');
    }
});

// Ruta para eliminar una película, solo para administradores
app.delete('/eliminarPelicula/:id', isAdmin, async (req, res) => {
    const peliculaId = req.params.id;
    
    try {
        const peliculaEliminada = await Peliculas.findByIdAndDelete(peliculaId);
        console.log('Película eliminada:', peliculaEliminada);
        res.status(200).send('Película eliminada exitosamente');
    } catch (error) {
        console.error('Error al eliminar película:', error);
        res.status(500).send('Error al eliminar la película');
    }
});

// Rutas de autenticación de usuario
app.post('/register', async (req, res) => {
    const { username, password } = req.body;
    console.log('Datos recibidos en el registro:', { username, password });
    try {
        const user = new User({ username, password });
        await user.save();
        console.log('Usuario registrado en la base de datos:', user);
        res.sendFile(path.join(__dirname, 'public', 'index.html'));
    } catch (error) {
        console.error('Error al registrar usuario:', error);
        if (error.name === 'MongoError' && error.code === 11000 && error.keyPattern && error.keyPattern.username === 1) {
            res.status(400).send('El nombre de usuario ya está en uso');
        } else {
            res.status(500).send('ERROR AL REGISTRAR AL USUARIO');
        }
    }
});

// Rutas de autenticación de administrador
app.post('/registeradmin', async (req, res) => {
    const { username, password } = req.body;
    console.log('Datos recibidos en el registro de administrador:', { username, password });
    try {
        const admin = new Admin({ username, password });
        await admin.save();
        console.log('Administrador registrado en la base de datos:', admin);
        res.sendFile(path.join(__dirname, 'public', 'indexadm.html'));
    } catch (error) {
        console.error('Error al registrar administrador:', error);
        if (error.name === 'MongoError' && error.code === 11000 && error.keyPattern && error.keyPattern.username === 1) {
            res.status(400).send('El nombre de administrador ya está en uso');
        } else {
            res.status(500).send('ERROR AL REGISTRAR AL ADMINISTRADOR');
        }
    }
});

module.exports = app;
